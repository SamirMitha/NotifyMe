# NotifyMe - Travel Timer

NotifyMe - Travel Timer is a Python library consisting of functions for predicting travel times. The included functions can fetch distance and directions between two addresses and includes weather multipliers and public transit delays scraped from Twitter for both the TTC and YRT in Toronto, Ontario.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install notifyme-traveltimer
```

## Usage
